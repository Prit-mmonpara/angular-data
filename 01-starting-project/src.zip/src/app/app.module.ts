import { NgModule } from "@angular/core";

@NgModule({
    declarations: []
})
export class AppModule {
    
}