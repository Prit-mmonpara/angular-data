import { Component } from '@angular/core';

@Component({
  selector: 'app-learning-resources',
  templateUrl: './learning-resources.component.html',
  styleUrl: './learning-resources.component.css',
  standalone: true,
})
export class LearningResourcesComponent {}
