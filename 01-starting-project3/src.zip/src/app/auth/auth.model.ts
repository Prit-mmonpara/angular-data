export type Permission = 'admin' | 'user' | 'guest';
